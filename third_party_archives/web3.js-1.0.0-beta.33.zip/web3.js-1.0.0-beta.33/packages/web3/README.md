# web3

This is a main package of [web3.js](https://github.com/ethereum/web3.js)

Please read the main [readme](https://github.com/ethereum/web3.js/blob/1.0/README.md) and [documentation](https://web3js.readthedocs.io/en/1.0/) for more.

## Installation

### Node.js

```bash
npm install web3
```
